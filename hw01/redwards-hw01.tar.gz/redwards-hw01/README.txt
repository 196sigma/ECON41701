Reginald Edwards
9 April 2012
reginald.edwards@gmail.com

This folder contains my solution to Homework 1: Problem 2.

Running "hw01sol-2.sh" will produce the graphs of the population dydnamics.



